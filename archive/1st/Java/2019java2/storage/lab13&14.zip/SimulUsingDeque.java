public class SimulUsingDeque {
    class Queue {
        int front;
        int rear;
        int queueSize;
        int queueArr[];
        public Queue(int queueSize) {
            front = -1;
            rear = -1;
            this.queueSize = queueSize;
            queueArr = new int[this.queueSize];
        }
        public boolean isEmpty() {
            return (front == rear);
        }
        public void enqueue(int item) {
            queueArr[++rear] = item;
            System.out.println("Inserted: " + item);
        }
        public int dequeue() {
            if (isEmpty()) {
                System.out.println("Queue is Empty");
                return 0;
            } else {
                System.out.println("Deleted: " + queueArr[front+1]);
                front = (front + 1)%this.queueSize;
                return queueArr[front];
            }
        }
        public int peek() {
            if (isEmpty()) {
                System.out.println("Queue is Empty");
            } else {
                System.out.println("Peeked: " + queueArr[front+1]);
                return queueArr[front+1];
            }
        }
    }

    class Stack {
        int top;
        int[] stack;
        int size;

        public Stack(int size) {
            top = -1;
            stack = new int[size];
            this.size = size;
        }
        public int top() {      //peek right?
            return stack[top];
        }
        public void push(int value) {
            stack[++top] = value;
            System.out.println(stack[top] + "PUSHED");
        }
        public int pop() {
            System.out.println(stack[top] + "POPPED");
            return stack[top--];

        }
        public boolean isEmpty() {
            if (top == -1) {
                return false;
            } else {
                return true;
            }
        }
    }
}

