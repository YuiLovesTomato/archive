
public class DListNode {
	String data;
	DListNode llink;
	DListNode rlink;
	public DListNode(){
		data=null;
		llink=null;
		rlink=null;
	}
	public DListNode(String x){
		data=x;
		llink=null;
		rlink=null;
	}
}
