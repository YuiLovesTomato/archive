

public class DLinkedList {
	private DListNode head, tail;
	public DLinkedList(){
	}
	public void insertFirst(String x){
		DListNode newNode = new DListNode(x);
		if(head==null){ //���� ����Ʈ�� ���Ҿ���
			head =newNode;
			tail = newNode;
			return ; //�ƹ��͵� �������� �ʰ� DLinedList()�� ����
		}
		newNode.rlink=head;
		head.llink=newNode;
		head=newNode;
	}
	public void insertLast(String x) {
		DListNode newNode = new DListNode(x);
		DListNode p = head;
		if (head == null) {
			head = newNode;
			tail = newNode;
			return;
		}
		while(p.rlink != null) {
			p = p.rlink;
		}
		p.rlink = newNode;
		newNode.llink = p;
		tail = newNode;
		
	}
	public String deleteFirst() {
		String x = " ";
		if (head == null) {
			return "No element";
		}
		x = head.data;
		head = head.rlink;
		if (!isEmpty()) {
		head.llink = null;
		}
		else { tail = null; }
		return x;
	}
	public String deleteLast(){
		//ä����
		String x;
		DListNode p;
		DListNode q;
		
		if (tail == null) { 
			return "No element found"; 
		}
		x = tail.data;
		tail=tail.llink;
		if(!isEmpty()) {
			tail.rlink = null;
		}
		else { head = null; }
		
		return x;
	}
	public int findData(String x){ //Z�� �� ��° ������������ ��ȯ�ϴ� �޼ҵ�
		int cnt=0;
		DListNode p=head;
		if(isEmpty()) return 0;
		while(p.rlink!=null){
			if(p.data.compareTo(x)==0) { 
				return cnt;
			}
			p=p.rlink;
			cnt++;
		}
		return -99;
	}
	public void deleteNode(String y){
		DListNode p;
		p=head;
		while(p.rlink!=null){
			if((p.data==y)&&(p==head)){
				head=head.rlink;
				head.llink=null;
			}
			else if(p.data==y){
				p.llink.rlink=p.rlink;
				p.rlink.llink=p.llink;
			}
			p=p.rlink;
		}
	}
	public void printList(){
		DListNode p;
		p = head;
		System.out.print("(");
		while(p!=null){
			System.out.print(p.data);
			p=p.rlink;
			if(p!=null){
				System.out.print(", ");
			}
		}
		System.out.println(")");
	}
	public void peekFirst() {
		DListNode p;
		p = head;
		if (isEmpty()) {
			System.out.println("peekFirst(): List is Empty");
		} else {
			System.out.println(p.data);
		}
	}
	public void peekLast() {
		DListNode p;
		p = tail;
		if (isEmpty()) {
			System.out.println("peekLast(): List is Empty");
		} else {
			System.out.println(p.data);
		}
	}
	public boolean isEmpty() {
		if (head == null) {
			return true;
		} else {
			return false;
		}
	}
}
