public class DLinkedListMain {
	public static void main(String args[]){
		DLinkedList list1 = new DLinkedList();
		list1.insertFirst("Kim");
		list1.insertFirst("Choi");
		list1.insertFirst("Lee");
		list1.insertFirst("Park");	//P L C K
		list1.deleteNode("Lee");	//P C K

		list1.insertFirst("Yoo");	
		list1.insertFirst("Hong");	//H Y P C K
		list1.insertLast("Sun");	//H Y P C K S

		list1.peekFirst();	//peek H
		list1.peekLast();	//peek S

		while(!list1.isEmpty()){
			list1.deleteFirst();	//clear list
		}

		list1.deleteLast();	//error: empty list
		list1.printList();	//same
		
		list1.findData("Choi");	//4��° �����Ͱ� choi 
		System.out.println(list1.findData("Choi"));	//[3]
		list1.deleteLast();
		list1.deleteFirst();
		list1.printList();	//Y P C
	}
}
    