import java.util.Deque;
import java.util.Stack;
import java.util.Iterator;
import java.util.LinkedList;

class Node0 {

	int i;
	String name;
	int score;

	Node0(int i, String name, int score) {
		this.i = i;
		this.name = name;
		this.score = score;
	}
}

public class AverageDeque <E> {
	
	public static void main(String[] args) {
		Deque<Node0> dq = new LinkedList<Node0>();
		Stack<Node0> s1 = new Stack<Node0>();

		double avg;
		int sum = 0;
		
		//initializing nodes
		Node0 node1 = new Node0(1, "Kim", 88);
		Node0 node2 = new Node0(2, "Choi", 92);
		Node0 node3 = new Node0(3, "Park", 39);
		Node0 node4 = new Node0(4, "Lee", 56);
		Node0 node5 = new Node0(5, "Jung", 91);
		Node0 node6 = new Node0(6, "Han", 49);
		Node0 node7 = new Node0(7, "Kwak", 82);
		Node0 node8 = new Node0(8, "Song", 75);
		Node0 node9 = new Node0(9, "Seo", 19);
		Node0 node10 = new Node0(10, "Bae", 48);
		
		//init stack
		s1.add(node1);
		s1.add(node2);
		s1.add(node3);
		s1.add(node4);
		s1.add(node5);
		s1.add(node6);
		s1.add(node7);
		s1.add(node8);
		s1.add(node9);
		s1.add(node10);

		//init deque
		dq.add(node1);
		dq.add(node2);
		dq.add(node3);
		dq.add(node4);
		dq.add(node5);
		dq.add(node6);
		dq.add(node7);
		dq.add(node8);
		dq.add(node9);
		dq.add(node10);

		//reverse stack
		Iterator it1 = s1.iterator();
		while(it1.hasNext()) {
			Node0 tmp = (Node0)it1.next();
			System.out.printf("id: %02d, name: %4s, score: %s\n", tmp.i, tmp.name, tmp.score);
		}
		
		//average deque
		Iterator it2 = dq.iterator();
		System.out.println("--Average Dequeue--");
		while (it2.hasNext()) {
			Node0 tmp = (Node0)it2.next();	//Object to Node0
			sum += tmp.score;
		}
		avg = sum/10.0;


		
		System.out.printf("sum: %d, avg: %.02f\n\n", sum, avg);
		
	}
	

}
